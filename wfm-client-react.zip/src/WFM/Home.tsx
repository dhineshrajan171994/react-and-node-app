import {Table, Button, Form} from 'react-bootstrap';
import Modal from 'react-modal';
import React, { useState, useEffect } from 'react';
import axios from 'axios';

const WFMHome=()=>{
    const [showConfirmBox, setConfirmBox] = useState(false);

    const confirmBoxClose = () => {
        setConfirmBox(false);
    }

    useEffect(()=> {
        console.log("Called");
        const username = localStorage.getItem("username");
        axios.post("http://localhost:8000/manager/employees",{ 
            username: username 
        })
        .then(function (response) {
            console.log(response);
        })
        .catch(function (error) {
            console.log(error);
        });
    }, [showConfirmBox]);

    return (
        <div className="manager_screen_container manager_wfm">
            <h1>WFM Home</h1>
            <Table striped bordered hover className="manager_screen manager_wfm_screen">
                <thead>
                <tr>
                    <th>Employee_id</th>
                    <th>Requestee</th>
                    <th>Request Date</th>
                    <th>Manager</th>
                    <th></th>
                </tr>
                </thead>
                <tbody>
                <tr>
                    <th>10001</th>
                    <th>Rohit</th>
                    <th>13-10-21</th>
                    <th>Karan</th>
                    <th><Button variant="primary" onClick={ ()=> setConfirmBox(true) }>View Details</Button></th>
                </tr>
                </tbody>
            </Table>

            <Modal
                    isOpen={showConfirmBox}
                    onRequestClose={confirmBoxClose}
                    contentLabel="manager Popup"
                    ariaHideApp={false}
                >
                <h2>Stock Lock Request Confirmation</h2>
                <form className="request_modal">
                    <Form.Label>Status Update for Request Lock</Form.Label>
                    <Form.Label>Employee Id: 10001</Form.Label>
                    <Form.Label>Requestee: Rohit</Form.Label>
                    <Form.Label>Employee Manager: Karan</Form.Label>
                    <Form.Label>Request Description: Need this Employee</Form.Label>
                    <Form.Group className="mb-3" controlId="requestTextarea">
                        <Form.Label>Status</Form.Label>
                        <Form.Select aria-label="status">
                            <option value=""></option>
                            <option value="update">Update</option>
                            <option value="reject">Reject</option>
                        </Form.Select>
                    </Form.Group>
                    <Button variant="secondary" onClick={confirmBoxClose}>
                        Cancel
                    </Button>{' '}
                    <Button variant="primary">
                        Send Request
                    </Button>
                </form>
            </Modal>
        </div>
    )
}

export default WFMHome