import {Table, Button, Form} from 'react-bootstrap';
import Modal from 'react-modal';
import React, { useState, useEffect } from 'react';
import axios from 'axios';
import $ from 'jquery';

const ManagerHome=()=>{
    const [showConfirmBox, setConfirmBox] = useState(false);
    const [modalId, setModalId] = useState(-1);
    const [modalName, setModalName] = useState('');
    const [managerDetails, setManagerDetails] = useState([]);
    const [errorMessage, setErrorMessage] = useState('');

    const confirmBoxClose = () => {
        setConfirmBox(false);
    }

    const requestLock = (managerId, managerName) => {
        console.log(managerId);
        console.log("managerId");
        setModalId(managerId);
        setModalName(managerName)
        setConfirmBox(true);
    }

    useEffect(()=> {
        console.log("Called");
        const username = localStorage.getItem("username");
        axios.post("http://localhost:8000/manager/employees",{ 
            username: username 
        })
        .then(function (response) {
            console.log(response);
            setManagerDetails(response.data);
        })
        .catch(function (error) {
            console.log(error);
        });
    }, []);

    const updateLockDescription = (event) => {
        event.preventDefault();
        event.stopPropagation();
        setErrorMessage("");
        let employee_id = modalId;
        let manager_name = modalName;
        console.log(employee_id);
        
        let value = $('#requestTextarea').val();
        if(value.length < 10) {
            setErrorMessage("Must enter atleast 10 Characters");
        }else {
            axios.put("http://localhost:8000/manager/insertsoftlock",{ 
                employeeid: employee_id,
                manager: manager_name,
                requestmessage: value
            })
            .then(function (response) {
                setConfirmBox(false);
                console.log(response);
            })
            .catch(function (error) {
                console.log(error);
            });
        }

    }

    return (
        <div className="manager_screen_container">
            <h1>Managers Home</h1>
            <Table striped bordered hover className="manager_screen">
                <thead>
                <tr>
                    <th>Employee_id</th>
                    <th>Name</th>
                    <th>Skills</th>
                    <th>Experience</th>
                    <th>Manager</th>
                    <th></th>
                </tr>
                </thead>
                <tbody>
                {managerDetails.map((manager, i) => (
                    <tr key={i}>
                    <td>{manager["EmployeeID"]}</td>
                    <td>{manager["Name"]}</td>
                    <td>{manager["Skills"]}</td>
                    <td>{manager["Experience"]}</td>
                    <td>{manager["Manager"]}</td>
                    <td><Button variant="primary" onClick={ ()=> requestLock(manager["EmployeeID"], manager["Manager"]) }>Request Lock</Button></td>
                    </tr>
                ))}
                </tbody>
            </Table>

            <Modal
                    isOpen={showConfirmBox}
                    onRequestClose={confirmBoxClose}
                    contentLabel="manager Popup"
                    ariaHideApp={false}
                >
                <h2>Stock Lock Request Confirmation</h2>
                <Form noValidate onSubmit={updateLockDescription}>
                    <Form.Label>Please Confirm the lock request for {modalId}</Form.Label>
                    <Form.Group className="mb-3" controlId="requestTextarea" aria-required="true">
                        <Form.Label>Request Message(message must be atleast 10 char long)</Form.Label>
                        <Form.Control as="textarea" rows={5} required/>
                    </Form.Group>
                    {
                        errorMessage && <p className="error-message">{errorMessage}</p>
                    }
                    <Button variant="secondary" onClick={confirmBoxClose}>
                        Cancel
                    </Button>{' '}
                    <Button variant="primary" type="submit">
                        Send Request
                    </Button>
                </Form>
            </Modal>
        </div>
    )
}

export default ManagerHome